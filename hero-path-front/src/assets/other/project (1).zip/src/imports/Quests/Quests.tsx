import svgPaths from "./svg-2tfr450i41";
import img261 from "./f47a03b8dc82ad15045ccd0c7df28f719cccfb01.png";
import imgEllipse22 from "./45efabb9145b05ed239cc7def9c817c85a12c14d.png";

function Frame19() {
  return (
    <div className="absolute content-stretch flex gap-[3px] items-center left-0 top-[11px]">
      <div className="h-[60px] relative shrink-0 w-[167px]" data-name="лого-26 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[105%] left-[1.62%] max-w-none top-[-5%] w-[98.56%]" src={img261} />
        </div>
      </div>
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#f5f5f5] text-[28px] whitespace-nowrap">{`Путь героя `}</p>
      <div className="absolute flex h-[48px] items-center justify-center left-[157px] top-[6px] w-0" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "21" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[48px]">
            <div className="absolute inset-[-2px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 2">
                <line id="Line 24" stroke="var(--stroke-0, white)" strokeWidth="2" x2="48" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-center flex flex-wrap gap-[0px_5px] items-center justify-end relative shrink-0 w-[218px]">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[22px] text-white whitespace-nowrap">Имя пользователя</p>
      <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[normal] relative shrink-0 text-[#ffd900] text-[20px] whitespace-nowrap">Money:</p>
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#ffd900] text-[20px] whitespace-nowrap">9.99</p>
      <div className="relative shrink-0 size-[18px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
          <circle cx="9" cy="9" fill="var(--fill-0, #FFD900)" id="Ellipse 23" r="9" />
        </svg>
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex items-start justify-between left-[887px] top-[17px] w-[276px]">
      <Frame />
      <div className="relative shrink-0 size-[48px]">
        <img alt="" className="absolute block inset-0 max-w-none size-full" height="48" src={imgEllipse22} width="48" />
      </div>
    </div>
  );
}

function Frame29() {
  return (
    <div className="bg-gradient-to-l from-[rgba(90,30,142,0)] h-[52px] overflow-clip relative shrink-0 to-[rgba(90,30,142,0)] via-[49.519%] via-[rgba(154,51,244,0)] w-[100px]">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[48px] top-1/2" data-name="Иконка-Главная">
        <div className="absolute h-[32px] left-[7px] top-[8px] w-[33px]">
          <div className="absolute inset-[2.79%_4.69%_9.55%_4.69%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.9069 28.0512">
              <path d={svgPaths.p1478a600} fill="var(--fill-0, #9A33F4)" id="Polygon 7" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame37() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame29 />
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] min-w-full relative shrink-0 text-[#9a33f4] text-[16px] text-center w-[min-content]">Главная</p>
    </div>
  );
}

function Frame33() {
  return (
    <div className="bg-gradient-to-l from-[rgba(90,30,142,0)] h-[52px] overflow-clip relative shrink-0 to-[rgba(90,30,142,0)] via-[49.519%] via-[rgba(154,51,244,0)] w-[100px]">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[48px] top-1/2" data-name="Иконка-Профиль">
        <div className="absolute h-[16px] left-[8px] top-[25px] w-[32px]">
          <div className="absolute inset-[0_9.34%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26.025 16">
              <path d={svgPaths.p2d558400} fill="var(--fill-0, #9A33F4)" id="Ellipse 35" />
            </svg>
          </div>
        </div>
        <div className="absolute left-[17px] size-[14px] top-[8px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <circle cx="7" cy="7" fill="var(--fill-0, #9A33F4)" id="Ellipse 36" r="7" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame35() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame33 />
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] min-w-full relative shrink-0 text-[#9a33f4] text-[16px] text-center w-[min-content]">Профиль</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute h-[29px] left-[8px] top-[9px] w-[32px]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 29">
        <g id="Group 21">
          <rect fill="var(--fill-0, #F5F5F5)" height="5" id="Rectangle 532" rx="2.5" width="22" x="10" y="1" />
          <rect fill="var(--fill-0, #F5F5F5)" height="5" id="Rectangle 533" rx="2.5" width="22" x="10" y="12" />
          <rect fill="var(--fill-0, #F5F5F5)" height="5" id="Rectangle 534" rx="2.5" width="22" x="10" y="23" />
          <circle cx="3.5" cy="14.5" fill="var(--fill-0, #F5F5F5)" id="Ellipse 32" r="3.5" />
          <circle cx="3.5" cy="25.5" fill="var(--fill-0, #F5F5F5)" id="Ellipse 34" r="3.5" />
          <circle cx="3.5" cy="3.5" fill="var(--fill-0, #F5F5F5)" id="Ellipse 33" r="3.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame26() {
  return (
    <div className="bg-gradient-to-l from-[rgba(90,30,142,0)] h-[52px] overflow-clip relative shrink-0 to-[rgba(90,30,142,0)] via-[49.519%] via-[rgba(154,51,244,0.69)] w-full">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[48px] top-1/2" data-name="Иконка-Квесты">
        <Group2 />
      </div>
    </div>
  );
}

function Frame27() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame26 />
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#9a33f4] text-[16px] text-center w-full">Квесты</p>
    </div>
  );
}

function Frame30() {
  return (
    <div className="bg-gradient-to-l from-[rgba(90,30,142,0)] h-[52px] overflow-clip relative shrink-0 to-[rgba(90,30,142,0)] via-[49.519%] via-[rgba(154,51,244,0)] w-[100px]">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[48px] top-1/2" data-name="Иконка-Магазин">
        <div className="absolute h-[18px] left-[7px] top-[9px] w-[33px]">
          <div className="absolute inset-[0_4.69%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.9067 18">
              <path d={svgPaths.p1d441d00} fill="var(--fill-0, #9A33F4)" id="Vector 7" />
            </svg>
          </div>
        </div>
        <div className="absolute left-[11px] size-[8px] top-[31px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
            <circle cx="4" cy="4" fill="var(--fill-0, #9A33F4)" id="Ellipse 39" r="4" />
          </svg>
        </div>
        <div className="absolute left-[27px] size-[8px] top-[31px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
            <circle cx="4" cy="4" fill="var(--fill-0, #9A33F4)" id="Ellipse 39" r="4" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame36() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame30 />
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#9a33f4] text-[16px] text-center whitespace-nowrap">Магазин</p>
    </div>
  );
}

function Frame31() {
  return (
    <div className="bg-gradient-to-l from-[rgba(90,30,142,0)] h-[52px] overflow-clip relative shrink-0 to-[rgba(90,30,142,0)] via-[49.519%] via-[rgba(154,51,244,0)] w-[100px]">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[48px] top-1/2" data-name="Иконка-Лидеры">
        <div className="-translate-y-1/2 absolute h-[40px] left-[6px] top-[calc(50%-8px)] w-[36px]">
          <div className="absolute inset-[38.1%_6.06%_0_5.89%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31.696 24.7595">
              <path d={svgPaths.p18cb9a80} fill="var(--fill-0, #9A33F4)" id="Vector 12" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame28() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-[100px]">
      <Frame31 />
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] min-w-full relative shrink-0 text-[#9a33f4] text-[16px] text-center w-[min-content]">Лидеры</p>
    </div>
  );
}

function Frame34() {
  return (
    <div className="bg-gradient-to-l from-[rgba(90,30,142,0)] h-[52px] overflow-clip relative shrink-0 to-[rgba(90,30,142,0)] via-[49.519%] via-[rgba(154,51,244,0)] w-[100px]">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[48px] top-1/2" data-name="Иконка-Отряды">
        <div className="absolute h-[13px] left-0 top-[26px] w-[32px]">
          <div className="absolute inset-[0_13%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.6813 13">
              <path d={svgPaths.p5059000} fill="var(--fill-0, #9A33F4)" id="Ellipse 35" />
            </svg>
          </div>
        </div>
        <div className="absolute h-[13px] left-[16px] top-[26px] w-[32px]">
          <div className="absolute inset-[0_13%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.6813 13">
              <path d={svgPaths.p5059000} fill="var(--fill-0, #9A33F4)" id="Ellipse 35" />
            </svg>
          </div>
        </div>
        <div className="absolute left-[7px] size-[14px] top-[9px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <circle cx="7" cy="7" fill="var(--fill-0, #9A33F4)" id="Ellipse 36" r="7" />
          </svg>
        </div>
        <div className="absolute left-[25px] size-[14px] top-[9px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <circle cx="7" cy="7" fill="var(--fill-0, #9A33F4)" id="Ellipse 36" r="7" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame32() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame34 />
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] min-w-full relative shrink-0 text-[#9a33f4] text-[16px] text-center w-[min-content]">Отряды</p>
    </div>
  );
}

function Frame38() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start py-[20px] relative shrink-0 w-full">
      <Frame37 />
      <Frame35 />
      <Frame27 />
      <Frame36 />
      <Frame28 />
      <Frame32 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-end flex flex-wrap gap-[16px_32px] items-end justify-center leading-[normal] relative shrink-0 text-center w-full whitespace-nowrap">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold relative shrink-0 text-[#9a33f4] text-[24px]">Активные</p>
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 text-[#848484] text-[22px]">Выполненные</p>
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 text-[#848484] text-[22px]">История наград</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="h-[14px] relative shrink-0 w-[659px]">
      <div className="absolute inset-[-100.71%_0_-172.14%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 659 52.2">
          <g id="Group 15">
            <line id="Line 26" stroke="var(--stroke-0, #9A33F4)" strokeLinecap="round" strokeWidth="4" x1="2" x2="657" y1="21.1" y2="21.1" />
            <g filter="url(#filter0_d_6_670)" id="Rectangle 531">
              <path d={svgPaths.p10682c00} fill="var(--fill-0, #9A33F4)" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="52.2" id="filter0_d_6_670" width="162.2" x="42.4" y="6.6312e-08">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="2" result="effect1_dropShadow_6_670" />
              <feOffset dx="5" dy="5" />
              <feGaussianBlur stdDeviation="8.55" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.603922 0 0 0 0 0.2 0 0 0 0 0.956863 0 0 0 1 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_6_670" />
              <feBlend in="SourceGraphic" in2="effect1_dropShadow_6_670" mode="normal" result="shape" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center relative w-[659px]">
      <Frame23 />
      <Group1 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="bg-[#f5f5f5] content-stretch flex h-[93px] items-center justify-center overflow-clip relative rounded-[24px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] w-[700px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame24 />
        </div>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="h-[133px] relative shrink-0 w-[132px]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 132 133">
        <g id="Group 11">
          <path d={svgPaths.p3e2f500} fill="var(--fill-0, #9A33F4)" id="Vector 5" />
          <path d={svgPaths.p345cdc80} fill="var(--fill-0, #9A33F4)" id="Vector 6" />
          <rect fill="var(--fill-0, #9A33F4)" height="19" id="Rectangle 524" rx="1" width="19" x="56" y="57" />
        </g>
      </svg>
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col font-['TT_Firs_Neue:Bold',sans-serif] items-start leading-[normal] min-w-px not-italic relative text-[#9a33f4]">
      <p className="relative shrink-0 text-[36px] w-full">Серия:</p>
      <p className="relative shrink-0 text-[28px] w-full">12 дней без опозданий</p>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex gap-[7px] items-center relative shrink-0 w-full">
      <Group />
      <Frame14 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex font-['Montserrat:SemiBold',sans-serif] font-semibold items-center justify-between leading-[normal] relative shrink-0 text-[22px] w-full whitespace-nowrap">
      <p className="relative shrink-0 text-[#848484]">7 дней</p>
      <p className="relative shrink-0 text-[#121212]">14 дней</p>
    </div>
  );
}

function Frame2() {
  return (
    <div className="bg-[#121212] flex-[1_0_0] h-[12px] min-w-px relative rounded-[6px]">
      <div className="content-stretch flex flex-col items-start pl-[3px] pr-[90px] py-[3px] relative size-full">
        <div className="bg-[#f5f5f5] h-[6px] relative rounded-[5px] shrink-0 w-full" />
      </div>
    </div>
  );
}

function Component1() {
  return (
    <div className="content-stretch flex gap-[8px] h-[30px] items-center relative shrink-0 w-full" data-name="Прогресс-бар">
      <div className="relative shrink-0 size-[30px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
          <circle cx="15" cy="15" fill="var(--fill-0, #9A33F4)" id="Ellipse 25" r="11.5" stroke="var(--stroke-0, #F5F5F5)" strokeWidth="7" />
        </svg>
      </div>
      <Frame2 />
      <div className="relative shrink-0 size-[30px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
          <circle cx="15" cy="15" fill="var(--fill-0, #121212)" id="Ellipse 26" r="11.5" stroke="var(--stroke-0, #F5F5F5)" strokeWidth="7" />
        </svg>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex font-['Montserrat:SemiBold',sans-serif] font-semibold items-center justify-between leading-[normal] relative shrink-0 text-[22px] w-full whitespace-nowrap">
      <p className="relative shrink-0 text-[#848484]">+5 монет</p>
      <p className="relative shrink-0 text-[#9a33f4]">+15 монет</p>
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <Frame3 />
      <Component1 />
      <Frame4 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 w-full">
      <Frame15 />
      <Frame17 />
    </div>
  );
}

function Component() {
  return (
    <div className="absolute bg-[#f5f5f5] content-stretch flex flex-col items-center justify-center left-[1090px] overflow-clip p-[20px] rounded-[24px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] top-[316px] w-[340px]" data-name="Блок-Серия">
      <Frame16 />
    </div>
  );
}

function Component3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Активный квест">
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#f5f5f5] text-[28px] w-full">Активный квест</p>
    </div>
  );
}

function Frame44() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#9a33f4] text-[22px] whitespace-nowrap">Ежедневный</p>
      <div className="overflow-clip relative shrink-0 size-[32px]" data-name="Иконка-Отряды">
        <div className="absolute h-[19.762px] left-[4.61px] top-[5.93px] w-[22.71px]" data-name="Union">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.7106 19.7621">
            <path d={svgPaths.pb537dc0} fill="var(--fill-0, #9A33F4)" id="Union" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame49() {
  return (
    <div className="content-stretch flex items-start justify-between mb-[-4px] relative shrink-0 w-full">
      <Frame44 />
      <div className="bg-[#121212] content-stretch flex h-[27px] items-center justify-center px-[16px] relative rounded-[48px] shrink-0">
        <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[16px] whitespace-nowrap">
          <span className="leading-[normal]">Осталось</span>
          <span className="leading-[normal]">{` `}</span>
          <span className="leading-[normal] text-[#9a33f4]">2 дня</span>
        </p>
      </div>
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic opacity-80 relative shrink-0 text-[#5d33f4] text-[36px] whitespace-nowrap">77%</p>
    </div>
  );
}

function Frame50() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[normal] min-h-px relative w-full">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold relative shrink-0 text-[#121212] text-[24px] whitespace-nowrap">Название</p>
      <p className="flex-[1_0_0] font-['Montserrat:Medium',sans-serif] font-medium min-h-px min-w-full relative text-[#292929] text-[20px] w-[min-content]">Сдать КТ по Python до пятницы пппаа</p>
    </div>
  );
}

function Frame51() {
  return (
    <div className="content-stretch flex flex-col h-[99px] items-start relative shrink-0 w-full">
      <Frame49 />
      <Frame50 />
    </div>
  );
}

function Component5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Информация">
      <Frame51 />
    </div>
  );
}

function Frame39() {
  return (
    <div className="bg-[#121212] flex-[1_0_0] h-[12px] min-w-px relative rounded-[6px]">
      <div className="content-stretch flex flex-col items-start pl-[3px] pr-[90px] py-[3px] relative size-full">
        <div className="bg-[#5f3ed6] h-[6px] relative rounded-[5px] shrink-0 w-[39px]" />
      </div>
    </div>
  );
}

function Component6() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-end min-h-px relative w-full" data-name="прогресс">
      <div className="content-stretch flex gap-[11px] items-center relative shrink-0 w-full">
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FD4E4E)" id="Ellipse 27" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#fd4e4e] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FFD900)" id="Ellipse 28" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#ffd900] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #5F3ED6)" id="Ellipse 29" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <Frame39 />
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" id="Ellipse 30" r="11.5" stroke="var(--stroke-0, #6CD63E)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="bg-[#f5f5f5] h-[235px] relative rounded-[8px] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-start p-[20px] relative size-full">
          <Component5 />
          <Component6 />
          <div className="bg-[#121212] relative rounded-[12px] shrink-0 w-full">
            <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
              <div className="content-stretch flex items-center justify-center px-[16px] py-[8px] relative size-full">
                <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[22px] whitespace-nowrap">
                  <span className="leading-[normal]">{`Награда: `}</span>
                  <span className="leading-[normal] text-[#ffd900]">+999 монет</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Frame45() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#9a33f4] text-[22px] whitespace-nowrap">Еженедельный</p>
      <div className="overflow-clip relative shrink-0 size-[32px]" data-name="Иконка-Отряды">
        <div className="absolute h-[18px] left-[5.33px] top-[7.33px] w-[21.333px]" data-name="Union">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.3333 18">
            <path d={svgPaths.pba00a00} fill="var(--fill-0, #9A33F4)" id="Union" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame53() {
  return (
    <div className="content-stretch flex items-start justify-between mb-[-4px] relative shrink-0 w-full">
      <Frame45 />
      <div className="bg-[#121212] content-stretch flex h-[27px] items-center justify-center px-[16px] relative rounded-[48px] shrink-0">
        <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[16px] whitespace-nowrap">
          <span className="leading-[normal]">Осталось</span>
          <span className="leading-[normal]">{` `}</span>
          <span className="leading-[normal] text-[#9a33f4]">2 дня</span>
        </p>
      </div>
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic opacity-80 relative shrink-0 text-[#5d33f4] text-[36px] whitespace-nowrap">77%</p>
    </div>
  );
}

function Frame54() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[normal] min-h-px relative w-full">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold relative shrink-0 text-[#121212] text-[24px] whitespace-nowrap">Название</p>
      <p className="flex-[1_0_0] font-['Montserrat:Medium',sans-serif] font-medium min-h-px min-w-full relative text-[#292929] text-[20px] w-[min-content]">Сдать КТ по Python до пятницы пппаа</p>
    </div>
  );
}

function Frame52() {
  return (
    <div className="content-stretch flex flex-col h-[99px] items-start relative shrink-0 w-full">
      <Frame53 />
      <Frame54 />
    </div>
  );
}

function Component7() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Информация">
      <Frame52 />
    </div>
  );
}

function Frame40() {
  return (
    <div className="bg-[#121212] flex-[1_0_0] h-[12px] min-w-px relative rounded-[6px]">
      <div className="content-stretch flex flex-col items-start pl-[3px] pr-[90px] py-[3px] relative size-full">
        <div className="bg-[#5f3ed6] h-[6px] relative rounded-[5px] shrink-0 w-[39px]" />
      </div>
    </div>
  );
}

function Component8() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-end min-h-px relative w-full" data-name="прогресс">
      <div className="content-stretch flex gap-[11px] items-center relative shrink-0 w-full">
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FD4E4E)" id="Ellipse 27" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#fd4e4e] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FFD900)" id="Ellipse 28" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#ffd900] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #5F3ED6)" id="Ellipse 29" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <Frame40 />
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" id="Ellipse 30" r="11.5" stroke="var(--stroke-0, #6CD63E)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="bg-[#f5f5f5] h-[235px] relative rounded-[8px] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-start p-[20px] relative size-full">
          <Component7 />
          <Component8 />
          <div className="bg-[#121212] relative rounded-[12px] shrink-0 w-full">
            <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
              <div className="content-stretch flex items-center justify-center px-[16px] py-[8px] relative size-full">
                <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[22px] whitespace-nowrap">
                  <span className="leading-[normal]">{`Награда: `}</span>
                  <span className="leading-[normal] text-[#ffd900]">+999 монет</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Frame46() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#9a33f4] text-[22px] whitespace-nowrap">Сезонный</p>
      <div className="overflow-clip relative shrink-0 size-[32px]" data-name="Иконка-Отряды">
        <div className="absolute h-[21.246px] left-[5.33px] top-[5.33px] w-[21.686px]" data-name="Union">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.6855 21.2461">
            <path d={svgPaths.p15a11cc0} fill="var(--fill-0, #9A33F4)" id="Union" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame56() {
  return (
    <div className="content-stretch flex items-start justify-between mb-[-4px] relative shrink-0 w-full">
      <Frame46 />
      <div className="bg-[#121212] content-stretch flex h-[27px] items-center justify-center px-[16px] relative rounded-[48px] shrink-0">
        <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[16px] whitespace-nowrap">
          <span className="leading-[normal]">Осталось</span>
          <span className="leading-[normal]">{` `}</span>
          <span className="leading-[normal] text-[#9a33f4]">2 дня</span>
        </p>
      </div>
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic opacity-80 relative shrink-0 text-[#5d33f4] text-[36px] whitespace-nowrap">77%</p>
    </div>
  );
}

function Frame57() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[normal] min-h-px relative w-full">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold relative shrink-0 text-[#121212] text-[24px] whitespace-nowrap">Название</p>
      <p className="flex-[1_0_0] font-['Montserrat:Medium',sans-serif] font-medium min-h-px min-w-full relative text-[#292929] text-[20px] w-[min-content]">Сдать КТ по Python до пятницы пппаа</p>
    </div>
  );
}

function Frame55() {
  return (
    <div className="content-stretch flex flex-col h-[99px] items-start relative shrink-0 w-full">
      <Frame56 />
      <Frame57 />
    </div>
  );
}

function Component9() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Информация">
      <Frame55 />
    </div>
  );
}

function Frame41() {
  return (
    <div className="bg-[#121212] flex-[1_0_0] h-[12px] min-w-px relative rounded-[6px]">
      <div className="content-stretch flex flex-col items-start pl-[3px] pr-[90px] py-[3px] relative size-full">
        <div className="bg-[#5f3ed6] h-[6px] relative rounded-[5px] shrink-0 w-[39px]" />
      </div>
    </div>
  );
}

function Component10() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-end min-h-px relative w-full" data-name="прогресс">
      <div className="content-stretch flex gap-[11px] items-center relative shrink-0 w-full">
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FD4E4E)" id="Ellipse 27" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#fd4e4e] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FFD900)" id="Ellipse 28" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#ffd900] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #5F3ED6)" id="Ellipse 29" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <Frame41 />
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" id="Ellipse 30" r="11.5" stroke="var(--stroke-0, #6CD63E)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#f5f5f5] h-[235px] relative rounded-[8px] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-start p-[20px] relative size-full">
          <Component9 />
          <Component10 />
          <div className="bg-[#121212] relative rounded-[12px] shrink-0 w-full">
            <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
              <div className="content-stretch flex items-center justify-center px-[16px] py-[8px] relative size-full">
                <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[22px] whitespace-nowrap">
                  <span className="leading-[normal]">{`Награда: `}</span>
                  <span className="leading-[normal] text-[#ffd900]">+999 монет</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Frame47() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#9a33f4] text-[22px] whitespace-nowrap">Личный</p>
      <div className="overflow-clip relative shrink-0 size-[32px]" data-name="Иконка-Профиль">
        <div className="absolute h-[10.667px] left-[5.33px] top-[16.67px] w-[21.333px]">
          <div className="absolute inset-[0_9.34%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.35 10.6667">
              <path d={svgPaths.p32a3a380} fill="var(--fill-0, #9A33F4)" id="Ellipse 35" />
            </svg>
          </div>
        </div>
        <div className="absolute left-[11.33px] size-[9.333px] top-[5.33px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.33333 9.33333">
            <circle cx="4.66667" cy="4.66667" fill="var(--fill-0, #9A33F4)" id="Ellipse 36" r="4.66667" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame59() {
  return (
    <div className="content-stretch flex items-start justify-between mb-[-4px] relative shrink-0 w-full">
      <Frame47 />
      <div className="bg-[#121212] content-stretch flex h-[27px] items-center justify-center px-[16px] relative rounded-[48px] shrink-0">
        <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[16px] whitespace-nowrap">
          <span className="leading-[normal]">Осталось</span>
          <span className="leading-[normal]">{` `}</span>
          <span className="leading-[normal] text-[#9a33f4]">2 дня</span>
        </p>
      </div>
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic opacity-80 relative shrink-0 text-[#5d33f4] text-[36px] whitespace-nowrap">77%</p>
    </div>
  );
}

function Frame60() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[normal] min-h-px relative w-full">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold relative shrink-0 text-[#121212] text-[24px] whitespace-nowrap">Название</p>
      <p className="flex-[1_0_0] font-['Montserrat:Medium',sans-serif] font-medium min-h-px min-w-full relative text-[#292929] text-[20px] w-[min-content]">Сдать КТ по Python до пятницы пппаа</p>
    </div>
  );
}

function Frame58() {
  return (
    <div className="content-stretch flex flex-col h-[99px] items-start relative shrink-0 w-full">
      <Frame59 />
      <Frame60 />
    </div>
  );
}

function Component11() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Информация">
      <Frame58 />
    </div>
  );
}

function Frame42() {
  return (
    <div className="bg-[#121212] flex-[1_0_0] h-[12px] min-w-px relative rounded-[6px]">
      <div className="content-stretch flex flex-col items-start pl-[3px] pr-[90px] py-[3px] relative size-full">
        <div className="bg-[#5f3ed6] h-[6px] relative rounded-[5px] shrink-0 w-[39px]" />
      </div>
    </div>
  );
}

function Component12() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-end min-h-px relative w-full" data-name="прогресс">
      <div className="content-stretch flex gap-[11px] items-center relative shrink-0 w-full">
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FD4E4E)" id="Ellipse 27" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#fd4e4e] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FFD900)" id="Ellipse 28" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#ffd900] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #5F3ED6)" id="Ellipse 29" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <Frame42 />
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" id="Ellipse 30" r="11.5" stroke="var(--stroke-0, #6CD63E)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="bg-[#f5f5f5] h-[235px] relative rounded-[8px] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-start p-[20px] relative size-full">
          <Component11 />
          <Component12 />
          <div className="bg-[#121212] relative rounded-[12px] shrink-0 w-full">
            <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
              <div className="content-stretch flex items-center justify-center px-[16px] py-[8px] relative size-full">
                <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[22px] whitespace-nowrap">
                  <span className="leading-[normal]">{`Награда: `}</span>
                  <span className="leading-[normal] text-[#ffd900]">+999 монет</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Frame48() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#9a33f4] text-[22px] whitespace-nowrap">Командный</p>
      <div className="overflow-clip relative shrink-0 size-[32px]" data-name="Иконка-Отряды">
        <div className="absolute h-[8.667px] left-[2.77px] top-[17.33px] w-[15.788px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.7875 8.66667">
            <path d={svgPaths.p3fc90400} fill="var(--fill-0, #9A33F4)" id="Ellipse 35" />
          </svg>
        </div>
        <div className="absolute h-[8.667px] left-[13.44px] top-[17.33px] w-[15.788px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.7875 8.66667">
            <path d={svgPaths.p3fc90400} fill="var(--fill-0, #9A33F4)" id="Ellipse 35" />
          </svg>
        </div>
        <div className="absolute left-[4.67px] size-[9.333px] top-[6px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.33333 9.33333">
            <path d={svgPaths.p2f016cf0} fill="var(--fill-0, #9A33F4)" id="Ellipse 36" />
          </svg>
        </div>
        <div className="absolute left-[16.67px] size-[9.333px] top-[6px]">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.33333 9.33333">
            <path d={svgPaths.p2f016cf0} fill="var(--fill-0, #9A33F4)" id="Ellipse 36" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame62() {
  return (
    <div className="content-stretch flex items-start justify-between mb-[-4px] relative shrink-0 w-full">
      <Frame48 />
      <div className="bg-[#121212] content-stretch flex h-[27px] items-center justify-center px-[16px] relative rounded-[48px] shrink-0">
        <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[16px] whitespace-nowrap">
          <span className="leading-[normal]">Осталось</span>
          <span className="leading-[normal]">{` `}</span>
          <span className="leading-[normal] text-[#9a33f4]">2 дня</span>
        </p>
      </div>
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic opacity-80 relative shrink-0 text-[#5d33f4] text-[36px] whitespace-nowrap">77%</p>
    </div>
  );
}

function Frame63() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[normal] relative shrink-0 w-full">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold relative shrink-0 text-[#121212] text-[24px] whitespace-nowrap">Название</p>
      <p className="font-['Montserrat:Medium',sans-serif] font-medium h-[25.5px] min-w-full relative shrink-0 text-[#292929] text-[20px] w-[min-content]">Сдать КТ по Python до пятницы пппаа</p>
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold h-[25.5px] min-w-full relative shrink-0 text-[#9a33f4] text-[20px] w-[min-content]">8 из 10 сдали КТ</p>
    </div>
  );
}

function Frame61() {
  return (
    <div className="content-stretch flex flex-col h-[99px] items-start relative shrink-0 w-full">
      <Frame62 />
      <Frame63 />
    </div>
  );
}

function Component13() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Информация">
      <Frame61 />
    </div>
  );
}

function Frame43() {
  return (
    <div className="bg-[#121212] flex-[1_0_0] h-[12px] min-w-px relative rounded-[6px]">
      <div className="content-stretch flex flex-col items-start pl-[3px] pr-[90px] py-[3px] relative size-full">
        <div className="bg-[#5f3ed6] h-[6px] relative rounded-[5px] shrink-0 w-[39px]" />
      </div>
    </div>
  );
}

function Component14() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-end min-h-px relative w-full" data-name="прогресс">
      <div className="content-stretch flex gap-[11px] items-center relative shrink-0 w-full">
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FD4E4E)" id="Ellipse 27" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#fd4e4e] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #FFD900)" id="Ellipse 28" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <div className="bg-[#ffd900] flex-[1_0_0] h-[6px] min-w-px relative rounded-[5px]">
          <div aria-hidden="true" className="absolute border-3 border-[#121212] border-solid inset-[-3px] pointer-events-none rounded-[8px]" />
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" fill="var(--fill-0, #5F3ED6)" id="Ellipse 29" r="11.5" stroke="var(--stroke-0, #121212)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
        <Frame43 />
        <div className="flex items-center justify-center relative shrink-0">
          <div className="-scale-y-100 flex-none">
            <div className="relative size-[30px]">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
                <circle cx="15" cy="15" id="Ellipse 30" r="11.5" stroke="var(--stroke-0, #6CD63E)" strokeWidth="7" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame9() {
  return (
    <div className="bg-[#f5f5f5] h-[263px] relative rounded-[8px] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-start p-[20px] relative size-full">
          <Component13 />
          <Component14 />
          <div className="bg-[#121212] relative rounded-[12px] shrink-0 w-full">
            <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
              <div className="content-stretch flex items-center justify-center px-[16px] py-[8px] relative size-full">
                <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[0] relative shrink-0 text-[#f5f5f5] text-[22px] whitespace-nowrap">
                  <span className="leading-[normal]">{`Награда: `}</span>
                  <span className="leading-[normal] text-[#ffd900]">+999 монет</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Component4() {
  return (
    <div className="flex-[1_0_0] min-h-px relative rounded-[16px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] w-full" data-name="Слот с квестами">
      <div aria-hidden="true" className="absolute bg-[#f5f5f5] inset-0 pointer-events-none rounded-[16px]" />
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-start p-[8px] relative size-full">
          <Frame5 />
          <Frame6 />
          <Frame7 />
          <Frame8 />
          <Frame9 />
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-16px_22.5px_0px_rgba(0,0,0,0.33)]" />
    </div>
  );
}

function Component15() {
  return (
    <div className="bg-[#f5f5f5] relative rounded-[16px] shrink-0 w-full" data-name="Кнопка-Подтвердить">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center justify-center px-[47px] py-[17px] relative size-full">
          <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[#121212] text-[24px] whitespace-nowrap">Подтвердить</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#121212] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[20px] items-start min-h-px relative w-full">
      <Component3 />
      <Component4 />
      <Component15 />
    </div>
  );
}

function Component2() {
  return (
    <div className="absolute bg-[#9a33f4] content-stretch flex flex-col gap-[10px] h-[796px] items-start left-[370px] overflow-clip p-[20px] rounded-[24px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] top-[251px] w-[700px]" data-name="Блок-Квестов">
      <Frame10 />
      <div className="bg-[#121212] relative rounded-[12px] shrink-0 w-full">
        <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
          <div className="content-stretch flex items-center justify-center px-[16px] py-[8px] relative size-full">
            <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#f5f5f5] text-[22px] whitespace-nowrap">Выполняется автоматически</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="bg-[#f5f5f5] relative rounded-[12px] shrink-0 w-full">
      <div className="flex flex-col items-end justify-end overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold gap-[8px] items-end justify-end p-[16px] relative size-full">
          <div className="leading-[0] min-w-full relative shrink-0 text-[22px] text-black w-[min-content] whitespace-pre-wrap">
            <p className="leading-[normal] mb-0 text-[#121212]">{`Название `}</p>
            <p className="leading-[normal] text-[#9a33f4]">полученные монеты</p>
          </div>
          <p className="leading-[normal] relative shrink-0 text-[#848484] text-[20px] whitespace-nowrap">Дата выполнения</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame11 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="bg-[#f5f5f5] relative rounded-[12px] shrink-0 w-full">
      <div className="flex flex-col items-end justify-end overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold gap-[8px] items-end justify-end p-[16px] relative size-full">
          <div className="leading-[0] min-w-full relative shrink-0 text-[22px] text-black w-[min-content] whitespace-pre-wrap">
            <p className="leading-[normal] mb-0 text-[#121212]">{`Название `}</p>
            <p className="leading-[normal] text-[#9a33f4]">полученные монеты</p>
          </div>
          <p className="leading-[normal] relative shrink-0 text-[#848484] text-[20px] whitespace-nowrap">1 час назад</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame20 />
    </div>
  );
}

function Frame22() {
  return (
    <div className="bg-[#f5f5f5] relative rounded-[12px] shrink-0 w-full">
      <div className="flex flex-col items-end justify-end overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold gap-[8px] items-end justify-end p-[16px] relative size-full">
          <div className="leading-[0] min-w-full relative shrink-0 text-[22px] text-black w-[min-content] whitespace-pre-wrap">
            <p className="leading-[normal] mb-0 text-[#121212]">{`Название `}</p>
            <p className="leading-[normal] text-[#9a33f4]">полученные монеты</p>
          </div>
          <p className="leading-[normal] relative shrink-0 text-[#848484] text-[20px] whitespace-nowrap">1 час назад</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame22 />
    </div>
  );
}

function Frame64() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0 w-full">
      <Frame12 />
      <Frame18 />
      <Frame21 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start relative shrink-0 w-full">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[#9a33f4] text-[24px] w-full">Список выполненных квестов за последние 30 дней</p>
      <Frame64 />
      <div className="bg-[#f5f5f5] h-[63px] relative rounded-[16px] shrink-0 w-full">
        <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
          <div className="content-stretch flex items-center justify-center px-[20px] py-[17px] relative size-full">
            <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[#9a33f4] text-[24px] whitespace-nowrap">Показать ещё</p>
          </div>
        </div>
        <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
      </div>
    </div>
  );
}

function Component16() {
  return (
    <div className="absolute bg-[#f5f5f5] content-stretch flex flex-col h-[608px] items-start left-[1090px] overflow-clip p-[20px] rounded-[24px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] top-[638px] w-[340px]" data-name="Блок-Ленты активности">
      <Frame13 />
    </div>
  );
}

function Component17() {
  return (
    <div className="absolute bg-[#9a33f4] content-stretch flex flex-col gap-[10px] items-start left-[1090px] overflow-clip p-[20px] rounded-[24px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] top-[138px] w-[340px]" data-name="Блок-Квестов">
      <div className="bg-[#9a33f4] h-[63px] relative rounded-[16px] shrink-0 w-full">
        <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
          <div className="content-stretch flex items-center justify-center px-[20px] py-[17px] relative size-full">
            <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[#f5f5f5] text-[24px] whitespace-nowrap">Самоотчёт</p>
          </div>
        </div>
        <div aria-hidden="true" className="absolute border-4 border-[#f5f5f5] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
      </div>
      <div className="bg-[#121212] h-[45px] relative rounded-[16px] shrink-0 w-full">
        <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
          <div className="content-stretch flex items-center justify-center px-[20px] py-[17px] relative size-full">
            <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[#f5f5f5] text-[24px] whitespace-nowrap">Пожаловаться</p>
          </div>
        </div>
        <div aria-hidden="true" className="absolute border-4 border-[#f5f5f5] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
      </div>
    </div>
  );
}

function Frame74() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#848484] text-[20px] whitespace-nowrap">Текст</p>
    </div>
  );
}

function Frame73() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap gap-y-[8px] items-center justify-between min-h-px relative w-full">
      <Frame74 />
      <div className="overflow-clip relative shrink-0 size-[32px]" data-name="Иконка-Отряды">
        <div className="absolute left-[5.33px] size-[21.333px] top-[5.33px]" data-name="Union">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.3333 21.3333">
            <path d={svgPaths.p2f39fdc0} fill="var(--fill-0, #9A33F4)" id="Union" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Component18() {
  return (
    <div className="bg-[#9a33f4] h-[48px] relative rounded-[48px] shrink-0 w-full" data-name="Ежедневный/категория">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center justify-center px-[24px] py-[3px] relative size-full">
          <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[#f5f5f5] text-[24px] whitespace-nowrap">Отправить</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-4 border-[#f5f5f5] border-solid inset-0 pointer-events-none rounded-[48px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
    </div>
  );
}

function Frame75() {
  return (
    <div className="content-stretch flex flex-col items-start justify-end relative shrink-0 w-full">
      <Component18 />
    </div>
  );
}

function Frame76() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[16px] items-start min-h-px relative w-full">
      <div className="content-stretch flex flex-col gap-[6px] h-[38px] items-center relative shrink-0 w-full" data-name="Поле ввода">
        <Frame73 />
        <div className="h-0 relative shrink-0 w-full">
          <div className="absolute inset-[-4px_0_0_0]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 4">
              <line id="Line 52" stroke="var(--stroke-0, #848484)" strokeLinecap="round" strokeWidth="4" x1="2" x2="298" y1="2" y2="2" />
            </svg>
          </div>
        </div>
      </div>
      <Frame75 />
    </div>
  );
}

function Frame70() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0 w-full">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#121212] text-[20px] w-full">Сдать все КТ недели</p>
      <div className="bg-[#121212] h-[43px] relative rounded-[12px] shrink-0 w-full">
        <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
          <div className="content-stretch flex items-center justify-center px-[16px] py-[8px] relative size-full">
            <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#ffd900] text-[22px] whitespace-nowrap">+10 монет</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame69() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#9a33f4] text-[28px] w-full">Вариант A</p>
      <Frame70 />
      <button className="bg-[#9a33f4] cursor-pointer h-[63px] relative rounded-[16px] shrink-0 w-full">
        <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
          <div className="content-stretch flex items-center justify-center px-[20px] py-[17px] relative size-full">
            <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[#f5f5f5] text-[24px] text-left whitespace-nowrap">Выбрать</p>
          </div>
        </div>
        <div aria-hidden="true" className="absolute border-4 border-[#f5f5f5] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
      </button>
    </div>
  );
}

function Frame72() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0 w-full">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#121212] text-[20px] w-full">Помочь однокурснику с проектом</p>
      <div className="bg-[#121212] h-[43px] relative rounded-[12px] shrink-0 w-full">
        <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
          <div className="content-stretch flex items-center justify-center px-[16px] py-[8px] relative size-full">
            <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#ffd900] text-[22px] whitespace-nowrap">+10 монет</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame71() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#9a33f4] text-[28px] w-full">Вариант B</p>
      <Frame72 />
    </div>
  );
}

function Frame68() {
  return (
    <div className="content-start flex flex-wrap gap-[16px] items-start justify-center relative shrink-0 w-full">
      <div className="bg-[#f5f5f5] relative rounded-[24px] shrink-0 w-[289px]" data-name="Карта А">
        <div className="content-stretch flex flex-col items-start overflow-clip p-[20px] relative rounded-[inherit] size-full">
          <Frame69 />
        </div>
        <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-[-4px] pointer-events-none rounded-[28px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
      </div>
      <div className="bg-[#f5f5f5] relative rounded-[8px] shrink-0 w-[289px]" data-name="Карта А">
        <div className="content-stretch flex flex-col items-start overflow-clip p-[20px] relative rounded-[inherit] size-full">
          <Frame71 />
        </div>
        <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-[-4px] pointer-events-none rounded-[12px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
      </div>
    </div>
  );
}

function Frame67() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 w-full">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[24px] text-center text-white w-full">Выбери одно из двух заданий</p>
      <Frame68 />
    </div>
  );
}

function Frame66() {
  return (
    <div className="bg-[#9a33f4] relative rounded-[12px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start p-[20px] relative size-full">
          <Frame67 />
        </div>
      </div>
    </div>
  );
}

function Frame65() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <p className="font-['TT_Firs_Neue:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#9a33f4] text-[28px] w-full">Еженедельный выбор</p>
      <Frame66 />
    </div>
  );
}

function Component19() {
  return (
    <div className="absolute bg-[#f5f5f5] content-stretch flex flex-col items-start left-[370px] overflow-clip p-[20px] rounded-[24px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] top-[1067px] w-[700px]" data-name="Блок-Ленты активности">
      <Frame65 />
    </div>
  );
}

export default function Quests() {
  return (
    <div className="bg-[#f5f5f5] relative size-full" data-name="quests">
      <div className="-translate-x-1/2 absolute bg-[#9a33f4] h-[82px] left-1/2 overflow-clip rounded-[24px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] top-[26px] w-[1180px]" data-name="Heder">
        <Frame19 />
        <Frame1 />
      </div>
      <div className="absolute bg-[#f5f5f5] content-stretch flex flex-col items-center left-[1450px] overflow-clip py-[24px] rounded-[24px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)] top-[153px] w-[100px]">
        <Frame38 />
      </div>
      <div className="absolute bg-[#9a33f4] h-[64px] left-[1543px] rounded-[4px] shadow-[5px_5px_17.1px_2px_#9a33f4] top-[375px] w-[14px]" />
      <div className="-translate-x-1/2 absolute flex h-[93px] items-center justify-center left-[calc(50%-240px)] top-[138px] w-[700px]">
        <div className="-scale-y-100 flex-none">
          <Frame25 />
        </div>
      </div>
      <Component />
      <Component2 />
      <Component16 />
      <Component17 />
      <div className="absolute bg-[#f5f5f5] h-[142px] left-[970px] rounded-[12px] top-[286px] w-[340px]">
        <div className="content-stretch flex flex-col items-start overflow-clip p-[20px] relative rounded-[inherit] size-full">
          <Frame76 />
        </div>
        <div aria-hidden="true" className="absolute border-4 border-[#9a33f4] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[25px_25px_20px_-20px_rgba(0,0,0,0.45)]" />
      </div>
      <Component19 />
    </div>
  );
}