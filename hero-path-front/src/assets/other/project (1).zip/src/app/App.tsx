import svgPaths from "../imports/Quests/svg-2tfr450i41";
import img261 from "figma:asset/f47a03b8dc82ad15045ccd0c7df28f719cccfb01.png";
import imgEllipse22 from "figma:asset/45efabb9145b05ed239cc7def9c817c85a12c14d.png";
import { useState } from "react";

// ─── SVG Icon helpers ──────────────────────────────────────────────────────

function IconHome({ active }: { active?: boolean }) {
  const c = active ? "#F5F5F5" : "#9A33F4";
  return (
    <svg className="block size-full" fill="none" viewBox="0 0 29.9069 28.0512">
      <path d={svgPaths.p1478a600} fill={c} />
    </svg>
  );
}
function IconProfile({ active }: { active?: boolean }) {
  const c = active ? "#F5F5F5" : "#9A33F4";
  return (
    <svg className="block size-full" fill="none" viewBox="0 0 48 48">
      <circle cx="24" cy="18" r="8" fill={c} />
      <path d={svgPaths.p2d558400} fill={c} transform="translate(11,32) scale(0.95)" />
    </svg>
  );
}
function IconQuests({ active }: { active?: boolean }) {
  const c = active ? "#F5F5F5" : "#9A33F4";
  return (
    <svg className="block size-full" fill="none" viewBox="0 0 32 29">
      <rect fill={c} height="5" rx="2.5" width="22" x="10" y="1" />
      <rect fill={c} height="5" rx="2.5" width="22" x="10" y="12" />
      <rect fill={c} height="5" rx="2.5" width="22" x="10" y="23" />
      <circle cx="3.5" cy="3.5" fill={c} r="3.5" />
      <circle cx="3.5" cy="14.5" fill={c} r="3.5" />
      <circle cx="3.5" cy="25.5" fill={c} r="3.5" />
    </svg>
  );
}
function IconShop({ active }: { active?: boolean }) {
  const c = active ? "#F5F5F5" : "#9A33F4";
  return (
    <svg className="block size-full" fill="none" viewBox="0 0 48 48">
      <path d={svgPaths.p1d441d00} fill={c} transform="translate(9,9)" />
      <circle cx="20" cy="39" r="4" fill={c} />
      <circle cx="36" cy="39" r="4" fill={c} />
    </svg>
  );
}
function IconLeaders({ active }: { active?: boolean }) {
  const c = active ? "#F5F5F5" : "#9A33F4";
  return (
    <svg className="block size-full" fill="none" viewBox="0 0 31.696 24.7595">
      <path d={svgPaths.p18cb9a80} fill={c} />
    </svg>
  );
}
function IconSquads({ active }: { active?: boolean }) {
  const c = active ? "#F5F5F5" : "#9A33F4";
  return (
    <svg className="block size-full" fill="none" viewBox="0 0 48 48">
      <circle cx="16" cy="17" r="7" fill={c} />
      <circle cx="32" cy="17" r="7" fill={c} />
      <path d={svgPaths.p5059000} fill={c} transform="translate(2,32)" />
      <path d={svgPaths.p5059000} fill={c} transform="translate(18,32)" />
    </svg>
  );
}

// ─── Sidebar ───────────────────────────────────────────────────────────────

const navItems = [
  { id: "home", label: "Главная", Icon: IconHome },
  { id: "profile", label: "Профиль", Icon: IconProfile },
  { id: "quests", label: "Квесты", Icon: IconQuests },
  { id: "shop", label: "Магазин", Icon: IconShop },
  { id: "leaders", label: "Лидеры", Icon: IconLeaders },
  { id: "squads", label: "Отряды", Icon: IconSquads },
];

function Sidebar({ active }: { active: string }) {
  return (
    <div
      className="flex flex-col items-center gap-5 py-6 rounded-3xl overflow-hidden"
      style={{ width: 100, background: "#F5F5F5", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)", flexShrink: 0 }}
    >
      {navItems.map(({ id, label, Icon }) => {
        const isActive = active === id;
        return (
          <div key={id} className="flex flex-col items-center w-full">
            <div
              className="flex items-center justify-center w-full"
              style={{
                height: 52,
                background: isActive
                  ? "linear-gradient(to left, rgba(90,30,142,0), rgba(154,51,244,0.69), rgba(90,30,142,0))"
                  : "transparent",
              }}
            >
              <div style={{ width: 32, height: 32 }}>
                <Icon active={isActive} />
              </div>
            </div>
            <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 14, color: "#9A33F4", textAlign: "center" }}>
              {label}
            </span>
          </div>
        );
      })}
    </div>
  );
}

// ─── Header ────────────────────────────────────────────────────────────────

function Header() {
  return (
    <div
      className="flex items-center justify-between px-4 relative overflow-hidden"
      style={{ background: "#9A33F4", borderRadius: 24, height: 82, boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
    >
      <div className="flex items-center gap-1">
        <div style={{ width: 167, height: 60, flexShrink: 0, position: "relative", overflow: "hidden" }}>
          <img alt="logo" src={img261} style={{ position: "absolute", height: "105%", top: "-5%", left: "1.62%", width: "98.56%", maxWidth: "none" }} />
        </div>
        <span style={{ fontFamily: "'TT Firs Neue',sans-serif", fontWeight: 700, fontSize: 28, color: "#F5F5F5", whiteSpace: "nowrap" }}>
          Путь героя
        </span>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex flex-wrap items-center justify-end gap-x-1" style={{ width: 218 }}>
          <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 22, color: "#FFFFFF", whiteSpace: "nowrap", width: "100%", textAlign: "right" }}>
            Имя пользователя
          </span>
          <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 500, fontSize: 20, color: "#FFD900", whiteSpace: "nowrap" }}>Money:</span>
          <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#FFD900", whiteSpace: "nowrap" }}>9.99</span>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="9" fill="#FFD900" /></svg>
        </div>
        <img alt="Avatar" src={imgEllipse22} style={{ width: 48, height: 48, borderRadius: "50%" }} />
      </div>
    </div>
  );
}

// ─── Tab Bar ───────────────────────────────────────────────────────────────

const tabs = ["Активные", "Выполненные", "История наград"];

function TabBar({ active, onSelect }: { active: string; onSelect: (t: string) => void }) {
  return (
    <div
      className="flex items-end gap-8 px-6 overflow-hidden"
      style={{ background: "#F5F5F5", borderRadius: 24, height: 93, boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)", flexShrink: 0 }}
    >
      {tabs.map((tab) => {
        const isActive = active === tab;
        return (
          <div key={tab} className="flex flex-col items-center gap-1 pb-3 cursor-pointer" onClick={() => onSelect(tab)}>
            <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: isActive ? 700 : 600, fontSize: isActive ? 24 : 22, color: isActive ? "#9A33F4" : "#848484", whiteSpace: "nowrap" }}>
              {tab}
            </span>
            {isActive && (
              <div style={{ width: "100%", height: 4, borderRadius: 2, background: "#9A33F4", boxShadow: "5px 5px 17px 2px rgba(154,51,244,0.6)" }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Action Buttons Block (Самоотчёт / Пожаловаться) ──────────────────────

function ActionButtons() {
  return (
    <div
      className="flex flex-col gap-3 p-5 rounded-3xl overflow-hidden"
      style={{ background: "#9A33F4", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
    >
      {/* Самоотчёт */}
      <button
        className="relative cursor-pointer"
        style={{ height: 63, background: "#9A33F4", borderRadius: 16, border: "none", outline: "none" }}
      >
        <div aria-hidden="true" style={{ position: "absolute", inset: 0, border: "4px solid #F5F5F5", borderRadius: 16, pointerEvents: "none", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }} />
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 700, fontSize: 24, color: "#F5F5F5", position: "relative" }}>Самоотчёт</span>
      </button>
      {/* Пожаловаться */}
      <button
        className="relative cursor-pointer"
        style={{ height: 45, background: "#121212", borderRadius: 16, border: "none", outline: "none" }}
      >
        <div aria-hidden="true" style={{ position: "absolute", inset: 0, border: "4px solid #F5F5F5", borderRadius: 16, pointerEvents: "none", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }} />
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 700, fontSize: 24, color: "#F5F5F5", position: "relative" }}>Пожаловаться</span>
      </button>
    </div>
  );
}

// ─── Streak Block (Блок-Серия) ─────────────────────────────────────────────

function StreakBlock() {
  return (
    <div
      className="flex flex-col gap-4 p-5 rounded-3xl overflow-hidden"
      style={{ background: "#F5F5F5", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
    >
      <div className="flex items-center gap-2">
        {/* Lightning icon group (132×133) */}
        <div style={{ width: 66, height: 67, flexShrink: 0 }}>
          <svg width="66" height="67" viewBox="0 0 132 133" fill="none">
            <path d={svgPaths.p3e2f500} fill="#9A33F4" />
            <path d={svgPaths.p345cdc80} fill="#9A33F4" />
            <rect fill="#9A33F4" height="19" rx="1" width="19" x="56" y="57" />
          </svg>
        </div>
        <div className="flex flex-col">
          <span style={{ fontFamily: "'TT Firs Neue',sans-serif", fontWeight: 700, fontSize: 28, color: "#9A33F4" }}>Серия:</span>
          <span style={{ fontFamily: "'TT Firs Neue',sans-serif", fontWeight: 700, fontSize: 22, color: "#9A33F4", lineHeight: 1.3 }}>12 дней без опозданий</span>
        </div>
      </div>
      {/* Progress labels */}
      <div className="flex items-center justify-between">
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#848484" }}>7 дней</span>
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#121212" }}>14 дней</span>
      </div>
      {/* Progress bar */}
      <div className="flex items-center gap-2">
        <svg width="30" height="30" viewBox="0 0 30 30" fill="none">
          <circle cx="15" cy="15" r="11.5" fill="#9A33F4" stroke="#F5F5F5" strokeWidth="7" />
        </svg>
        <div style={{ flex: 1, height: 12, background: "#121212", borderRadius: 6, padding: "3px 90px 3px 3px" }}>
          <div style={{ height: 6, background: "#F5F5F5", borderRadius: 5 }} />
        </div>
        <svg width="30" height="30" viewBox="0 0 30 30" fill="none">
          <circle cx="15" cy="15" r="11.5" fill="#121212" stroke="#F5F5F5" strokeWidth="7" />
        </svg>
      </div>
      {/* Reward labels */}
      <div className="flex items-center justify-between">
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#848484" }}>+5 монет</span>
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#9A33F4" }}>+15 монет</span>
      </div>
    </div>
  );
}

// ─── Quest Card ────────────────────────────────────────────────────────────

type QuestType = "Ежедневный" | "Еженедельный" | "Сезонный" | "Личный" | "Командный";

function QuestCard({ type, tall }: { type: QuestType; tall?: boolean }) {
  return (
    <div
      className="relative rounded-lg shrink-0 w-full"
      style={{ background: "#F5F5F5", height: tall ? 263 : 235, border: "4px solid #9A33F4", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)", overflow: "hidden" }}
    >
      <div className="flex flex-col gap-3 p-5 size-full">
        {/* Header row */}
        <div className="flex items-start justify-between">
          <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 22, color: "#9A33F4" }}>{type}</span>
          <div className="flex items-center gap-3">
            <div style={{ background: "#121212", borderRadius: 48, height: 27, padding: "0 16px", display: "flex", alignItems: "center" }}>
              <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 16, color: "#F5F5F5" }}>
                Осталось <span style={{ color: "#9A33F4" }}>2 дня</span>
              </span>
            </div>
            <span style={{ fontFamily: "'TT Firs Neue',sans-serif", fontWeight: 700, fontSize: 36, color: "#5D33F4", opacity: 0.8 }}>77%</span>
          </div>
        </div>
        {/* Title + description */}
        <div className="flex flex-col gap-1">
          <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 700, fontSize: 24, color: "#121212" }}>Название</span>
          <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 500, fontSize: 20, color: "#292929" }}>Сдать КТ по Python до пятницы пппаа</span>
          {tall && (
            <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#9A33F4" }}>8 из 10 сдали КТ</span>
          )}
        </div>
        {/* Progress dots */}
        <div className="flex items-center gap-3 flex-1 items-end">
          {/* Red dot */}
          <svg width="30" height="30" viewBox="0 0 30 30" fill="none" style={{ flexShrink: 0 }}>
            <circle cx="15" cy="15" r="11.5" fill="#FD4E4E" stroke="#121212" strokeWidth="7" />
          </svg>
          <div style={{ flex: 1, height: 6, background: "#FD4E4E", borderRadius: 5, border: "3px solid #121212" }} />
          {/* Yellow dot */}
          <svg width="30" height="30" viewBox="0 0 30 30" fill="none" style={{ flexShrink: 0 }}>
            <circle cx="15" cy="15" r="11.5" fill="#FFD900" stroke="#121212" strokeWidth="7" />
          </svg>
          <div style={{ flex: 1, height: 6, background: "#FFD900", borderRadius: 5, border: "3px solid #121212" }} />
          {/* Purple dot */}
          <svg width="30" height="30" viewBox="0 0 30 30" fill="none" style={{ flexShrink: 0 }}>
            <circle cx="15" cy="15" r="11.5" fill="#5F3ED6" stroke="#121212" strokeWidth="7" />
          </svg>
          {/* Dark track with partial fill */}
          <div style={{ flex: 1, height: 12, background: "#121212", borderRadius: 6, padding: "3px 0 3px 3px", overflow: "hidden" }}>
            <div style={{ height: 6, width: 39, background: "#5F3ED6", borderRadius: 5 }} />
          </div>
          {/* Green dot (outline only) */}
          <svg width="30" height="30" viewBox="0 0 30 30" fill="none" style={{ flexShrink: 0 }}>
            <circle cx="15" cy="15" r="11.5" stroke="#6CD63E" strokeWidth="7" />
          </svg>
        </div>
        {/* Reward bar */}
        <div style={{ background: "#121212", borderRadius: 12, padding: "8px 16px", textAlign: "center" }}>
          <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 22, color: "#F5F5F5" }}>
            Награда: <span style={{ color: "#FFD900" }}>+999 монет</span>
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── Quest Main Block ──────────────────────────────────────────────────────

const questTypes: QuestType[] = ["Ежедневный", "Еженедельный", "Сезонный", "Личный", "Командный"];

function QuestBlock() {
  return (
    <div
      className="flex flex-col gap-3 p-5 rounded-3xl overflow-hidden"
      style={{ background: "#9A33F4", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
    >
      {/* Title */}
      <span style={{ fontFamily: "'TT Firs Neue',sans-serif", fontWeight: 700, fontSize: 28, color: "#F5F5F5" }}>
        Активный квест
      </span>

      {/* Quest cards slot */}
      <div
        className="flex flex-col gap-3 p-2 rounded-2xl overflow-y-auto"
        style={{
          background: "#F5F5F5",
          borderRadius: 16,
          boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45), inset 0px -16px 22.5px 0px rgba(0,0,0,0.33)",
          maxHeight: 620,
        }}
      >
        {questTypes.map((type) => (
          <QuestCard key={type} type={type} tall={type === "Командный"} />
        ))}
      </div>

      {/* Confirm button */}
      <button
        className="relative cursor-pointer w-full"
        style={{ background: "#F5F5F5", borderRadius: 16, height: 63, border: "none", outline: "none" }}
      >
        <div aria-hidden="true" style={{ position: "absolute", inset: 0, border: "4px solid #121212", borderRadius: 16, pointerEvents: "none" }} />
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 700, fontSize: 24, color: "#121212", position: "relative" }}>
          Подтвердить
        </span>
      </button>

      {/* Auto button */}
      <div style={{ background: "#121212", borderRadius: 12, padding: "8px 16px", textAlign: "center" }}>
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 22, color: "#F5F5F5" }}>
          Выполняется автоматически
        </span>
      </div>
    </div>
  );
}

// ─── Completed Quests Block ────────────────────────────────────────────────

const completedQuests = [
  { date: "Дата выполнения" },
  { date: "1 час назад" },
  { date: "1 час назад" },
];

function CompletedQuestsBlock() {
  return (
    <div
      className="flex flex-col gap-5 p-5 rounded-3xl overflow-hidden"
      style={{ background: "#F5F5F5", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
    >
      <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 700, fontSize: 24, color: "#9A33F4" }}>
        Список выполненных квестов за последние 30 дней
      </span>
      <div className="flex flex-col gap-3">
        {completedQuests.map((q, i) => (
          <div key={i} className="relative rounded-xl" style={{ background: "#F5F5F5", border: "4px solid #9A33F4", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}>
            <div className="flex flex-col items-end gap-2 p-4">
              <div style={{ width: "100%" }}>
                <p style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 22, color: "#121212", margin: 0 }}>Название</p>
                <p style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 22, color: "#9A33F4", margin: 0 }}>полученные монеты</p>
              </div>
              <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#848484" }}>{q.date}</span>
            </div>
          </div>
        ))}
      </div>
      {/* Show more button */}
      <button
        className="relative cursor-pointer w-full"
        style={{ height: 63, background: "#F5F5F5", borderRadius: 16, border: "none", outline: "none" }}
      >
        <div aria-hidden="true" style={{ position: "absolute", inset: 0, border: "4px solid #9A33F4", borderRadius: 16, pointerEvents: "none", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }} />
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 700, fontSize: 24, color: "#9A33F4", position: "relative" }}>
          Показать ещё
        </span>
      </button>
    </div>
  );
}

// ─── Weekly Choice Block ───────────────────────────────────────────────────

function WeeklyChoiceBlock() {
  return (
    <div
      className="flex flex-col gap-4 p-5 rounded-3xl overflow-hidden"
      style={{ background: "#F5F5F5", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
    >
      <span style={{ fontFamily: "'TT Firs Neue',sans-serif", fontWeight: 700, fontSize: 28, color: "#9A33F4" }}>
        Еженедельный выбор
      </span>
      <div
        className="rounded-xl overflow-hidden p-5 flex flex-col gap-4"
        style={{ background: "#9A33F4", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
      >
        <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 700, fontSize: 24, color: "#FFFFFF", textAlign: "center" }}>
          Выбери одно из двух заданий
        </span>
        <div className="flex gap-4 justify-center flex-wrap">
          {/* Variant A */}
          <div
            className="relative"
            style={{ width: 289, background: "#F5F5F5", borderRadius: 24, padding: 20, boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
          >
            <div aria-hidden="true" style={{ position: "absolute", inset: -4, border: "4px solid #9A33F4", borderRadius: 28, pointerEvents: "none" }} />
            <div className="flex flex-col gap-4">
              <span style={{ fontFamily: "'TT Firs Neue',sans-serif", fontWeight: 700, fontSize: 28, color: "#9A33F4" }}>Вариант A</span>
              <div className="flex flex-col gap-3">
                <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#121212" }}>Сдать все КТ недели</span>
                <div style={{ background: "#121212", borderRadius: 12, height: 43, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 22, color: "#FFD900" }}>+10 монет</span>
                </div>
              </div>
              <button
                className="relative cursor-pointer w-full"
                style={{ height: 63, background: "#9A33F4", borderRadius: 16, border: "none", outline: "none" }}
              >
                <div aria-hidden="true" style={{ position: "absolute", inset: 0, border: "4px solid #F5F5F5", borderRadius: 16, pointerEvents: "none", boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }} />
                <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 700, fontSize: 24, color: "#F5F5F5", position: "relative" }}>Выбрать</span>
              </button>
            </div>
          </div>
          {/* Variant B */}
          <div
            className="relative"
            style={{ width: 289, background: "#F5F5F5", borderRadius: 8, padding: 20, boxShadow: "25px 25px 20px -20px rgba(0,0,0,0.45)" }}
          >
            <div aria-hidden="true" style={{ position: "absolute", inset: -4, border: "4px solid #9A33F4", borderRadius: 12, pointerEvents: "none" }} />
            <div className="flex flex-col gap-4">
              <span style={{ fontFamily: "'TT Firs Neue',sans-serif", fontWeight: 700, fontSize: 28, color: "#9A33F4" }}>Вариант B</span>
              <div className="flex flex-col gap-3">
                <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 20, color: "#121212" }}>Помочь однокурснику с проектом</span>
                <div style={{ background: "#121212", borderRadius: 12, height: 43, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontFamily: "'Montserrat',sans-serif", fontWeight: 600, fontSize: 22, color: "#FFD900" }}>+10 монет</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── App ───────────────────────────────────────────────────────────────────

export default function App() {
  const [activeTab, setActiveTab] = useState("Активные");

  return (
    <div className="min-h-screen w-full" style={{ background: "#F5F5F5" }}>
      <div className="mx-auto" style={{ maxWidth: 1200, padding: "26px 20px 40px" }}>
        {/* Header */}
        <Header />

        {/* Body */}
        <div className="flex gap-4 mt-4">
          {/* Sidebar */}
          <Sidebar active="quests" />

          {/* Main content */}
          <div className="flex flex-col gap-4 flex-1 min-w-0">

            {/* Tab bar */}
            <TabBar active={activeTab} onSelect={setActiveTab} />

            <div className="flex gap-4 items-start">
              {/* Left column: quest block + weekly choice */}
              <div className="flex flex-col gap-4 flex-1 min-w-0">
                <QuestBlock />
                <WeeklyChoiceBlock />
              </div>

              {/* Right column: action buttons + streak + completed quests */}
              <div className="flex flex-col gap-4" style={{ width: 300, flexShrink: 0 }}>
                <ActionButtons />
                <StreakBlock />
                <CompletedQuestsBlock />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
