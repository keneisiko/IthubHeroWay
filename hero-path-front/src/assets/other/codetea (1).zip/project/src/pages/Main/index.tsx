import React from "react";
import styles from './index.module.css'
export default (props) => {
	return (
		<div className={styles["contain"]}>
			<div className={styles["view"]}>
				<div className={styles["column"]}>
					<div className={styles["row-view"]}>
						<div className={styles["row-view2"]}>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/bfnbkn8u_expires_30_days.png"} 
								className={styles["image"]}
							/>
							<span className={styles["text"]} >
								{"Путь героя"}
							</span>
						</div>
						<div className={styles["row-view3"]}>
							<div className={styles["column2"]}>
								<span className={styles["text2"]} >
									{"Имя пользователя"}
								</span>
								<div className={styles["row-view4"]}>
									<span className={styles["text3"]} >
										{"Money:"}
									</span>
									<span className={styles["text4"]} >
										{"9.99"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/5ziy1nif_expires_30_days.png"} 
										className={styles["image2"]}
									/>
								</div>
							</div>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/6ud0gzxn_expires_30_days.png"} 
								className={styles["image3"]}
							/>
						</div>
					</div>
					<div className={styles["row-view5"]}>
						<div className={styles["column3"]}>
							<div className={styles["column4"]}>
								<div className={styles["row-view6"]}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/6q7lpkkk_expires_30_days.png"} 
										className={styles["image4"]}
									/>
									<div className={styles["column5"]}>
										<span className={styles["text5"]} >
											{"Серия:"}
										</span>
										<span className={styles["text6"]} >
											{"12 дней без опозданий"}
										</span>
									</div>
								</div>
								<div className={styles["column6"]}>
									<div className={styles["row-view7"]}>
										<span className={styles["text7"]} >
											{"7 дней"}
										</span>
										<span className={styles["text8"]} >
											{"14 дней"}
										</span>
									</div>
									<div className={styles["row-view8"]}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/tfrpjowd_expires_30_days.png"} 
											className={styles["image5"]}
										/>
										<div className={styles["view2"]}>
											<div className={styles["box"]}>
											</div>
										</div>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/av2pawb9_expires_30_days.png"} 
											className={styles["image5"]}
										/>
									</div>
									<div className={styles["row-view7"]}>
										<span className={styles["text9"]} >
											{"+5 монет"}
										</span>
										<span className={styles["text10"]} >
											{"+15 монет"}
										</span>
									</div>
								</div>
							</div>
							<div className={styles["column7"]}>
								<div className={styles["column8"]}>
									<span className={styles["text11"]} >
										{"Текущий рейтинг:"}
									</span>
									<button className={styles["button"]}
										onClick={()=>alert("Pressed!")}>
										<span className={styles["text12"]} >
											{"199"}
										</span>
									</button>
								</div>
								<div className={styles["row-view7"]}>
									<span className={styles["text13"]} >
										{"Статус:"}
									</span>
									<button className={styles["button2"]}
										onClick={()=>alert("Pressed!")}>
										<span className={styles["text14"]} >
											{"Игрок"}
										</span>
									</button>
									<button className={styles["button3"]}
										onClick={()=>alert("Pressed!")}>
										<span className={styles["text14"]} >
											{"6 ур."}
										</span>
									</button>
								</div>
								<div className={styles["column9"]}>
									<div className={styles["row-view7"]}>
										<span className={styles["text15"]} >
											{"до"}
										</span>
										<button className={styles["button4"]}
											onClick={()=>alert("Pressed!")}>
											<span className={styles["text16"]} >
												{"Лидера"}
											</span>
										</button>
										<span className={styles["text16"]} >
											{"осталось:"}
										</span>
									</div>
									<button className={styles["button5"]}
										onClick={()=>alert("Pressed!")}>
										<span className={styles["text14"]} >
											{"150 баллов"}
										</span>
									</button>
								</div>
								<div className={styles["row-view8"]}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/2ujegf3a_expires_30_days.png"} 
										className={styles["image5"]}
									/>
									<div className={styles["view2"]}>
										<div className={styles["box"]}>
										</div>
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/18hq8ybc_expires_30_days.png"} 
										className={styles["image5"]}
									/>
								</div>
								<div className={styles["row-view7"]}>
									<span className={styles["text17"]} >
										{"Игрок"}
									</span>
									<span className={styles["text18"]} >
										{"Лидер"}
									</span>
								</div>
							</div>
						</div>
						<div className={styles["column10"]}>
							<div className={styles["column11"]}>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/rhlqjnu8_expires_30_days.png"} 
									className={styles["image6"]}
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/uax43i41_expires_30_days.png"} 
									className={styles["absolute-image"]}
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/hsq05rv4_expires_30_days.png"} 
									className={styles["absolute-image2"]}
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/u7b074pk_expires_30_days.png"} 
									className={styles["absolute-image3"]}
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/zf6ademk_expires_30_days.png"} 
									className={styles["absolute-image4"]}
								/>
							</div>
							<div className={styles["absolute-view"]}>
								<button className={styles["button6"]}
									onClick={()=>alert("Pressed!")}>
									<span className={styles["text19"]} >
										{"Ритм"}
									</span>
								</button>
							</div>
							<div className={styles["absolute-view"]}>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/jqu1ipx5_expires_30_days.png"} 
									className={styles["image7"]}
								/>
							</div>
						</div>
						<div className={styles["column12"]}>
							<div className={styles["column13"]}>
								<div className={styles["box2"]}>
								</div>
								<span className={styles["text20"]} >
									{"Главная"}
								</span>
								<div className={styles["column14"]}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/nu31r4fg_expires_30_days.png"} 
										className={styles["image8"]}
									/>
									<span className={styles["text21"]} >
										{"Профиль"}
									</span>
								</div>
								<div className={styles["column14"]}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/a4e7b52i_expires_30_days.png"} 
										className={styles["image8"]}
									/>
									<span className={styles["text22"]} >
										{"Квесты"}
									</span>
								</div>
								<div className={styles["column14"]}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/evei24a0_expires_30_days.png"} 
										className={styles["image8"]}
									/>
									<span className={styles["text23"]} >
										{"Магазин"}
									</span>
								</div>
								<div className={styles["column14"]}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/ksl6jwnj_expires_30_days.png"} 
										className={styles["image8"]}
									/>
									<span className={styles["text24"]} >
										{"Лидеры"}
									</span>
								</div>
								<div className={styles["column15"]}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/g07582qd_expires_30_days.png"} 
										className={styles["image8"]}
									/>
									<span className={styles["text25"]} >
										{"Отряды"}
									</span>
								</div>
							</div>
							<div className={styles["absolute-box"]}>
							</div>
						</div>
					</div>
					<div className={styles["row-view9"]}>
						<div className={styles["column16"]}>
							<span className={styles["text26"]} >
								{"Лента активности"}
							</span>
							<div className={styles["column8"]}>
								<button className={styles["button-column"]}
									onClick={()=>alert("Pressed!")}>
									<span className={styles["text27"]} >
										{"Получена нашивка <Железный ритм>"}
									</span>
									<span className={styles["text28"]} >
										{"1 час назад"}
									</span>
								</button>
								<button className={styles["button-column"]}
									onClick={()=>alert("Pressed!")}>
									<span className={styles["text27"]} >
										{"+3 монеты от @ivan за респект"}
									</span>
									<span className={styles["text29"]} >
										{"2 часа назад"}
									</span>
								</button>
								<button className={styles["button-column"]}
									onClick={()=>alert("Pressed!")}>
									<span className={styles["text27"]} >
										{"Серия 7 дней - +5 монет"}
									</span>
									<span className={styles["text29"]} >
										{"3 часа назад"}
									</span>
								</button>
							</div>
						</div>
						<div className={styles["column17"]}>
							<div className={styles["column18"]}>
								<div className={styles["column19"]}>
									<span className={styles["text30"]} >
										{"Активный квест"}
									</span>
									<div className={styles["row-view10"]}>
										<button className={styles["button7"]}
											onClick={()=>alert("Pressed!")}>
											<span className={styles["text16"]} >
												{"Ежедневный"}
											</span>
										</button>
										<button className={styles["button8"]}
											onClick={()=>alert("Pressed!")}>
											<span className={styles["text16"]} >
												{"Еженедельный"}
											</span>
										</button>
									</div>
								</div>
								<div className={styles["view3"]}>
									<div className={styles["column20"]}>
										<div className={styles["row-view7"]}>
											<span className={styles["text31"]} >
												{"Сдать КТ по Python"}
											</span>
											<span className={styles["text32"]} >
												{"77%"}
											</span>
										</div>
										<div className={styles["row-view8"]}>
											<img
												src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/y2z274g8_expires_30_days.png"} 
												className={styles["image5"]}
											/>
											<div className={styles["view4"]}>
												<div className={styles["box3"]}>
												</div>
											</div>
											<img
												src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/c167itc9_expires_30_days.png"} 
												className={styles["image5"]}
											/>
											<div className={styles["view4"]}>
												<div className={styles["box4"]}>
												</div>
											</div>
											<img
												src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/4renl8se_expires_30_days.png"} 
												className={styles["image5"]}
											/>
											<div className={styles["view5"]}>
												<div className={styles["box5"]}>
												</div>
											</div>
											<img
												src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/5wb7shqy_expires_30_days.png"} 
												className={styles["image5"]}
											/>
										</div>
									</div>
								</div>
								<button className={styles["button9"]}
									onClick={()=>alert("Pressed!")}>
									<span className={styles["text14"]} >
										{"Подтвердить"}
									</span>
								</button>
							</div>
							<div className={styles["column15"]}>
								<div className={styles["row-view11"]}>
									<div className={styles["view6"]}>
										<span className={styles["text33"]} >
											{"Текст"}
										</span>
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/GX9voqQxuD/79cruuwp_expires_30_days.png"} 
										className={styles["image9"]}
									/>
								</div>
								<div className={styles["box6"]}>
								</div>
								<button className={styles["button10"]}
									onClick={()=>alert("Pressed!")}>
									<span className={styles["text16"]} >
										{"Самоотчёт"}
									</span>
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}